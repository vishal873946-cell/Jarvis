package com.jarvis.android;

import android.Manifest;import android.app.*;import android.os.*;import android.content.*;import android.content.pm.PackageManager;import android.speech.*;import android.speech.tts.TextToSpeech;import android.net.Uri;import android.provider.Settings;import android.view.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
 TextView status,command; TextToSpeech tts;
 @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);status=findViewById(R.id.status);command=findViewById(R.id.command);Button btn=findViewById(R.id.listen);
  tts=new TextToSpeech(this,s->{if(s==TextToSpeech.SUCCESS) tts.setLanguage(new Locale("hi","IN"));});
  btn.setOnClickListener(v->listen());
  if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},7);
 }
 void listen(){Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"hi-IN");try{startActivityForResult(i,8);}catch(Exception e){speak("Speech recognition उपलब्ध नहीं है");}}
 @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==8&&c==RESULT_OK&&d!=null){ArrayList<String>x=d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(x!=null&&!x.isEmpty()) handle(x.get(0));}}
 void handle(String s){command.setText("आप: "+s);String q=s.toLowerCase(Locale.ROOT);if(q.contains("youtube")){open("https://www.youtube.com");speak("YouTube खोल रहा हूँ");}else if(q.contains("google")||q.contains("क्रोम")){open("https://www.google.com");speak("Google खोल रहा हूँ");}else if(q.contains("setting")||q.contains("सेटिंग")){startActivity(new Intent(Settings.ACTION_SETTINGS));speak("Settings खोल रहा हूँ");}else if(q.contains("bluetooth")){startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));speak("Bluetooth settings खोल रहा हूँ");}else if(q.contains("wifi")||q.contains("वाईफाई")){startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));speak("Wi-Fi settings खोल रहा हूँ");}else{speak("मैंने सुना: "+s+"। यह command अभी मेरे basic version में नहीं जोड़ी गई है।");}}
 void open(String u){startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)));}
 void speak(String s){status.setText("JARVIS: "+s);if(tts!=null)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"jarvis");}
 @Override protected void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}
