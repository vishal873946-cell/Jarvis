# Jarvis Android V1
Basic voice-controlled Android assistant. Commands currently include YouTube, Google/Chrome, Settings, Bluetooth settings, and Wi-Fi settings.

Build: push this folder to GitHub, open Actions, select `Build Jarvis APK`, choose `Run workflow`, then download the APK artifact.
